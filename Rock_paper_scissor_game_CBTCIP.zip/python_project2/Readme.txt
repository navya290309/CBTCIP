#this project has been maintained by Aryan Singh 
#under the guidance of CipherByte Technologies
#project name = ROCK, PAPER, SCISSOR GAME
#Requires one player



import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import random

user_wins = 0
computer_wins = 0
user_name = ""

def start_game():
    global user_name
    user_name = name_entry.get()
    if not user_name:
        messagebox.showwarning("Name Required", "Please enter your name before playing.")
        return

    # Hide the name entry window and show the main game window
    name_window.withdraw()
    show_game_window()

def show_game_window():
    global user_wins_label, computer_wins_label, result_label, result_text, timer_label
    global rock_button, paper_button, scissor_button  # Ensure these variables are global to reset the game

    game_window = tk.Toplevel()
    game_window.title("Rock Paper Scissor Game")
    game_window.geometry("500x500")
    game_window.config(bg='#F0F0F0')  # Light gray background

    # Load images
    rock_img = Image.open("rock.png")
    rock_img = rock_img.resize((80, 80), Image.LANCZOS)
    rock_photo = ImageTk.PhotoImage(rock_img)

    paper_img = Image.open("paper.png")
    paper_img = paper_img.resize((80, 80), Image.LANCZOS)
    paper_photo = ImageTk.PhotoImage(paper_img)

    scissor_img = Image.open("scissor.png")
    scissor_img = scissor_img.resize((80, 80), Image.LANCZOS)
    scissor_photo = ImageTk.PhotoImage(scissor_img)

    def reset_game():
        # Reset buttons state and clear result text after 3 seconds
        result_text.config(text="")
        timer_label.config(text="")
        rock_button.config(state=tk.NORMAL)
        paper_button.config(state=tk.NORMAL)
        scissor_button.config(state=tk.NORMAL)

    def play(user_choice):
        global user_wins, computer_wins
        choices = ['Rock', 'Paper', 'Scissor']
        computer_choice = random.choice(choices)
        result = ""
        
        if user_choice == computer_choice:
            result = "It's a tie!"
        elif (user_choice == 'Rock' and computer_choice == 'Scissor') or \
             (user_choice == 'Paper' and computer_choice == 'Rock') or \
             (user_choice == 'Scissor' and computer_choice == 'Paper'):
            result = "You win!"
            user_wins += 1
        else:
            result = "Computer wins!"
            computer_wins += 1
        
        user_wins_label.config(text=f"{user_name} Wins: {user_wins}")
        computer_wins_label.config(text=f"Computer Wins: {computer_wins}")
        result_text.config(text=f"{user_name} chose {user_choice}\nThe Computer chose {computer_choice}\n{result}")

        # Disable buttons after selection
        rock_button.config(state=tk.DISABLED)
        paper_button.config(state=tk.DISABLED)
        scissor_button.config(state=tk.DISABLED)

        # Reset the game after 3 seconds
        game_window.after(3000, reset_game)

    # Set up the wins labels frame
    wins_frame = tk.Frame(game_window, bg='#F0F0F0')
    wins_frame.pack(fill=tk.X, padx=20, pady=10)

    user_wins_label = tk.Label(wins_frame, text=f"{user_name} Wins: {user_wins}", font=('Helvetica', 12, 'bold'), fg="blue", bg='#F0F0F0')
    user_wins_label.pack(side=tk.LEFT)

    computer_wins_label = tk.Label(wins_frame, text="Computer Wins: 0", font=('Helvetica', 12, 'bold'), fg="red", bg='#F0F0F0')
    computer_wins_label.pack(side=tk.RIGHT)

    # Set up the labels and buttons
    label = tk.Label(game_window, text="Choose one:", font=('Helvetica', 18, 'bold'), bg='#F0F0F0')
    label.pack(pady=(30, 10))

    frame = tk.Frame(game_window, bg='#F0F0F0')
    frame.pack(pady=(10, 20))

    rock_button = tk.Button(frame, text="Rock", image=rock_photo, compound=tk.TOP, command=lambda: play('Rock'), font=('Helvetica', 12), bg='#E0E0E0', height=100, width=100)
    rock_button.grid(row=0, column=0, padx=20)

    paper_button = tk.Button(frame, text="Paper", image=paper_photo, compound=tk.TOP, command=lambda: play('Paper'), font=('Helvetica', 12), bg='#E0E0E0', height=100, width=100)
    paper_button.grid(row=0, column=1, padx=20)

    scissor_button = tk.Button(frame, text="Scissor", image=scissor_photo, compound=tk.TOP, command=lambda: play('Scissor'), font=('Helvetica', 12), bg='#E0E0E0', height=100, width=100)
    scissor_button.grid(row=0, column=2, padx=20)

    # Result display area
    result_frame = tk.Frame(game_window, bg='white', width=400, height=150, relief=tk.RIDGE, borderwidth=2)
    result_frame.pack(pady=20)

    result_label = tk.Label(result_frame, text="Game Results", font=('Helvetica', 16, 'bold'), bg='white')
    result_label.pack(pady=10)

    result_text = tk.Label(result_frame, text="", font=('Helvetica', 12), bg='white', wraplength=380, justify=tk.LEFT)
    result_text.pack(pady=(0, 10))

    # Timer display
    timer_label = tk.Label(game_window, text="", font=('Helvetica', 12, 'bold'), fg="green", bg='#F0F0F0')
    timer_label.pack(pady=10)

    # Ensure images are kept in memory
    rock_button.image = rock_photo
    paper_button.image = paper_photo
    scissor_button.image = scissor_photo

# Set up the initial name entry window
name_window = tk.Tk()
name_window.title("Enter Name")
name_window.geometry("300x150")
name_window.config(bg='#F0F0F0')

name_frame = tk.Frame(name_window, bg='#F0F0F0')
name_frame.pack(pady=(40, 10))

name_label = tk.Label(name_frame, text="Enter your name:", font=('Helvetica', 12), bg='#F0F0F0')
name_label.pack(side=tk.LEFT, padx=(0, 10))

name_entry = tk.Entry(name_frame, font=('Helvetica', 12))
name_entry.pack(side=tk.LEFT)

submit_button = tk.Button(name_window, text="Submit", font=('Helvetica', 12), bg='#E0E0E0', command=start_game)
submit_button.pack(pady=10)

# Start the GUI event loop
name_window.mainloop()
