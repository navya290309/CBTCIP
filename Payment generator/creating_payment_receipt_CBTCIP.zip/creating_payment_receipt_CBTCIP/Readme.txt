#this project has been maintained by Aryan Singh 
#under the guidance of CipherByte Technologies
#project name = Payment Receipt Generator
#Requires one person to operate



from tkinter import *
from tkinter import messagebox
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import HRFlowable
from datetime import datetime
import os

class ItemEntryWindow:
    def __init__(self, master, add_item_callback):
        self.master = master
        self.master.title("Add Items")
        self.add_item_callback = add_item_callback

        self.item_name_label = Label(master, text="Item Name:")
        self.item_name_label.grid(row=0, column=0, sticky=W, padx=10, pady=10)
        self.item_name_entry = Entry(master)
        self.item_name_entry.grid(row=0, column=1, padx=10, pady=10)

        self.item_quantity_label = Label(master, text="Quantity:")
        self.item_quantity_label.grid(row=1, column=0, sticky=W, padx=10, pady=10)
        self.item_quantity_entry = Entry(master)
        self.item_quantity_entry.grid(row=1, column=1, padx=10, pady=10)

        self.item_price_label = Label(master, text="Item Price (each):")
        self.item_price_label.grid(row=2, column=0, sticky=W, padx=10, pady=10)
        self.item_price_entry = Entry(master)
        self.item_price_entry.grid(row=2, column=1, padx=10, pady=10)

        self.add_item_button = Button(master, text="Add Item", command=self.add_item)
        self.add_item_button.grid(row=3, column=0, pady=10)

        self.confirm_button = Button(master, text="Confirm", command=self.confirm_items)
        self.confirm_button.grid(row=3, column=1, pady=10)

        self.items_list = Listbox(master, width=50, height=10)
        self.items_list.grid(row=4, column=0, columnspan=2, padx=10, pady=10)

    def add_item(self):
        item_name = self.item_name_entry.get()
        item_quantity = self.item_quantity_entry.get()
        item_price = self.item_price_entry.get()

        if not item_name or not item_quantity or not item_price:
            messagebox.showerror("Error", "Please enter item name, quantity, and price.")
            return

        try:
            item_quantity = int(item_quantity)
            item_price = float(item_price)
        except ValueError:
            messagebox.showerror("Error", "Please enter valid quantity and price.")
            return

        self.add_item_callback(item_name, item_quantity, item_price)
        self.items_list.insert(END, f"{item_name}: {item_quantity} @ Rs. {item_price:.2f} each")
        
        # Clear the entry fields for the next item
        self.item_name_entry.delete(0, END)
        self.item_quantity_entry.delete(0, END)
        self.item_price_entry.delete(0, END)

    def confirm_items(self):
        self.master.destroy()

class ReceiptGenerator:
    def __init__(self, master):
        self.master = master
        self.master.title("Payment Receipt Generator")

        self.receipt_id_file = "receipt_id.txt"
        self.receipt_id = self.get_next_receipt_id()

        self.items = []

        self.create_main_window()

    def get_next_receipt_id(self):
        if not os.path.exists(self.receipt_id_file):
            with open(self.receipt_id_file, 'w') as file:
                file.write('290300')
            return 290300
        else:
            with open(self.receipt_id_file, 'r+') as file:
                current_id = int(file.read().strip())
                next_id = current_id + 1
                file.seek(0)
                file.write(str(next_id))
                file.truncate()
            return next_id

    def create_receipt(self):
        date = datetime.now().strftime("%Y-%m-%d")
        customer_name = self.customer_name_entry.get()
        age = self.age_entry.get()
        contact_number = self.contact_number_entry.get()
        email_address = self.email_address_entry.get()

        total_amount = sum(item['price'] * item['quantity'] for item in self.items)
        total_quantity = sum(item['quantity'] for item in self.items)
        filepath = f"{customer_name}'s_payment_receipt_{self.receipt_id}.pdf"

        self.create_pdf_receipt(self.receipt_id, date, customer_name, age, contact_number, email_address, self.items, total_quantity, total_amount, filepath)

        messagebox.showinfo("Success", f"{customer_name}'s Receipt created successfully! Receipt ID: {self.receipt_id}")
        self.master.destroy()

    def create_pdf_receipt(self, receipt_id, date, customer_name, age, contact_number, email_address, items, total_quantity, total_amount, filepath):
        doc = SimpleDocTemplate(filepath, pagesize=letter, topMargin=1*cm, bottomMargin=1*cm, leftMargin=1*cm, rightMargin=1*cm)

        elements = []

        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Center', alignment=1))

        def add_border(canvas, doc):
            canvas.saveState()
            canvas.setStrokeColorRGB(0, 0, 0)
            canvas.setLineWidth(1)
            canvas.rect(cm, cm, doc.width, doc.height)
            canvas.restoreState()

        elements.append(Paragraph(f"<para align=center><font size=16><b>{customer_name}'s Bill</b></font></para>", styles['Center']))
        elements.append(Spacer(1, 12))

        elements.append(Paragraph(f"<para align=right><b>Receipt ID: {receipt_id}</b></para>", styles['Normal']))
        elements.append(Spacer(1, 12))

        elements.append(Paragraph(f"Customer Name: {customer_name}", styles['Normal']))
        elements.append(Paragraph(f"Age: {age}", styles['Normal']))
        elements.append(Paragraph(f"Contact Number: {contact_number}", styles['Normal']))
        elements.append(Paragraph(f"Email Address: {email_address}", styles['Normal']))
        elements.append(Spacer(1, 12))

        elements.append(HRFlowable(width="100%", thickness=1, lineCap='round', color=colors.black))
        elements.append(Spacer(1, 12))

        elements.append(Paragraph('<para align=center><font size=14><b>Items Purchased</b></font></para>', styles['Center']))
        elements.append(Spacer(1, 12))

        data = [
            ["Item Name", "Quantity", "Price (Rs.)", "Total (Rs.)"]
        ]

        for item in items:
            item_total = item['price'] * item['quantity']
            data.append([item['name'], str(item['quantity']), f"{item['price']:.2f}", f"{item_total:.2f}"])

        table = Table(data, colWidths=[doc.width/4-0.5*cm]*4)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))

        elements.append(table)
        elements.append(Spacer(1, 12))

        elements.append(Paragraph(f"<b>Total Quantity: {total_quantity}</b>", styles['Normal']))
        elements.append(Paragraph(f"<b>Total Amount: Rs. {total_amount:.2f}</b>", styles['Normal']))
        elements.append(Spacer(1, 12))

        elements.append(HRFlowable(width="100%", thickness=1, lineCap='round', color=colors.black))
        elements.append(Spacer(1, 12))

        thank_you_note = f"Thank you, dear {customer_name}, for shopping a total of Rs. {total_amount:.2f} with us. We would like to assist you more often. Keep shopping!"
        elements.append(Paragraph(thank_you_note, styles['Normal']))

        doc.build(elements, onFirstPage=add_border, onLaterPages=add_border)

    def open_item_entry_window(self):
        item_window = Toplevel(self.master)
        item_entry = ItemEntryWindow(item_window, self.add_item_to_receipt)
        self.master.wait_window(item_window)  # Wait for the item window to close before continuing

    def add_item_to_receipt(self, item_name, item_quantity, item_price):
        self.items.append({
            'name': item_name,
            'quantity': item_quantity,
            'price': item_price
        })
        self.update_items_display()

    def update_items_display(self):
        self.items_text.config(state=NORMAL)
        self.items_text.delete("1.0", END)
        for item in self.items:
            self.items_text.insert(END, f"{item['name']}: {item['quantity']} @ Rs. {item['price']:.2f}\n")
        self.items_text.config(state=DISABLED)

    def confirm_customer_details(self):
        self.customer_name_entry.config(state=DISABLED)
        self.age_entry.config(state=DISABLED)
        self.contact_number_entry.config(state=DISABLED)
        self.email_address_entry.config(state=DISABLED)
        self.add_item_button.config(state=NORMAL)

    def create_main_window(self):
        Label(self.master, text="Customer Name:").grid(row=0, column=0, sticky=W, pady=(10, 5))
        self.customer_name_entry = Entry(self.master)
        self.customer_name_entry.grid(row=0, column=1, pady=(10, 5))

        Label(self.master, text="Age:").grid(row=1, column=0, sticky=W, pady=5)
        self.age_entry = Entry(self.master)
        self.age_entry.grid(row=1, column=1, pady=5)

        Label(self.master, text="Contact Number:").grid(row=2, column=0, sticky=W, pady=5)
        self.contact_number_entry = Entry(self.master)
        self.contact_number_entry.grid(row=2, column=1, pady=5)

        Label(self.master, text="Email Address:").grid(row=3, column=0, sticky=W, pady=5)
        self.email_address_entry = Entry(self.master)
        self.email_address_entry.grid(row=3, column=1, pady=5)

        confirm_button = Button(self.master, text="Confirm", command=self.confirm_customer_details)
        confirm_button.grid(row=3, column=2, padx=10, pady=5)

        self.items_label = Label(self.master, text="Items Purchased:")
        self.items_label.grid(row=4, column=0, sticky=W, pady=(10, 5))
        self.items_text = Text(self.master, height=5, width=30, state=DISABLED)
        self.items_text.grid(row=4, column=1, pady=(10, 5))

        self.add_item_button = Button(self.master, text="Click to Add Item", command=self.open_item_entry_window, state=DISABLED)
        self.add_item_button.grid(row=5, column=0, columnspan=2, pady=10)

        generate_receipt_button = Button(self.master, text="Generate Receipt", command=self.create_receipt)
        generate_receipt_button.grid(row=6, column=0, columnspan=2, pady=10)

def main():
    root = Tk()
    app = ReceiptGenerator(root)
    root.mainloop()

if __name__ == "__main__":
    main()