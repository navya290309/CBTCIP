import tkinter as tk
from tkinter import messagebox, Toplevel, Listbox, Entry
from PIL import Image, ImageTk
import imageio
import sounddevice as sd
import numpy as np
import threading
import time
import os
import wavio

class VoiceRecorderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Voice Recorder")
        self.root.configure(bg='#050f28')
        self.root.geometry("500x500")  # Increased window size

        self.fs = 44100  # Sample rate (samples per second)
        self.filename_base = "recorded_audio"
        self.counter = 1  # Counter for filename incrementation
        self.audio_data = []

        self.is_recording = False
        self.is_paused = False
        self.elapsed_time = 0
        self.pause_start_time = 0

        self.create_widgets()
        self.load_gif()

    def create_widgets(self):
        self.info_label = tk.Label(self.root, text="Press the button to start recording:", bg='#050f28', fg='white', font=("Helvetica", 16))
        self.info_label.pack(pady=20)

        self.mic_button = tk.Button(self.root, text="Start", command=self.start_recording, bg='#8DECB4', fg='black', font=("Helvetica", 16), width=12, height=2, borderwidth=0)
        self.mic_button.pack(pady=20)
        self.mic_button.config(relief="groove", borderwidth=2)

        self.status_label = tk.Label(self.root, text="", bg='#050f28', fg='white', font=("Helvetica", 14))
        self.status_label.pack(pady=20)

        self.show_recordings_button = tk.Button(self.root, text="Show Recordings", command=self.show_recordings, bg='orange', font=("Helvetica", 14))
        self.show_recordings_button.pack(pady=20)

    def load_gif(self):
        self.gif_path = "gif.gif"
        self.gif = imageio.get_reader(self.gif_path)
        self.gif_frames = [Image.fromarray(frame) for frame in self.gif]
        self.current_frame = 0
        self.gif_running = False

    def update_gif(self):
        if self.gif_running:
            frame = self.gif_frames[self.current_frame]
            frame_image = ImageTk.PhotoImage(frame)
            self.gif_label.config(image=frame_image)
            self.gif_label.image = frame_image
            self.current_frame = (self.current_frame + 1) % len(self.gif_frames)
            self.control_window.after(50, self.update_gif)  # Adjust delay for frame rate

    def start_gif(self):
        self.gif_running = True
        self.update_gif()

    def stop_gif(self):
        self.gif_running = False

    def freeze_gif(self):
        self.gif_running = False
        # Keep the current frame displayed

    def unfreeze_gif(self):
        self.gif_running = True
        self.update_gif()

    def start_recording(self):
        self.is_recording = True
        self.is_paused = False
        self.mic_button.config(bg='#15F5BA', text="Recording", state=tk.DISABLED)
        self.status_label.config(text="Recording...")

        self.start_time = time.time()
        self.elapsed_time = 0
        self.audio_data = []
        threading.Thread(target=self.record_audio).start()

        # Create new window with Pause and Stop buttons, Timer, and GIF
        self.control_window = Toplevel(self.root)
        self.control_window.title("Recording Controls")
        self.control_window.geometry("400x500")  # Increased window size
        self.control_window.configure(bg='#050f28')

        self.pause_resume_button = tk.Button(self.control_window, text="Pause Recording", command=self.toggle_pause_resume, bg='#37B7C3', font=("Helvetica", 14))
        self.pause_resume_button.pack(pady=20)

        self.stop_button = tk.Button(self.control_window, text="Stop Recording", command=self.stop_recording, bg='red', font=("Helvetica", 14))
        self.stop_button.pack(pady=20)

        self.timer_label = tk.Label(self.control_window, text="Timer: 0 seconds", bg='#050f28', fg='white', font=("Helvetica", 16))
        self.timer_label.pack(pady=20)

        self.gif_label = tk.Label(self.control_window, bg='#050f28')
        self.gif_label.pack(pady=10)

        self.start_gif()
        self.update_timer()

    def stop_recording(self):
        self.is_recording = False
        self.is_paused = False
        self.mic_button.config(bg='#8DECB4', text="Start", state=tk.NORMAL)
        self.status_label.config(text="Recording finished.")
        self.stop_gif()
        self.control_window.destroy()
        self.show_save_edit_window()

    def toggle_pause_resume(self):
        if self.is_paused:
            self.resume_recording()
        else:
            self.pause_recording()

    def pause_recording(self):
        self.is_paused = True
        self.status_label.config(text="Recording paused.")
        self.pause_resume_button.config(text="Resume Recording", bg='#06D001')
        self.freeze_gif()
        self.pause_start_time = time.time()

    def resume_recording(self):
        self.is_paused = False
        self.status_label.config(text="Recording...")
        self.pause_resume_button.config(text="Pause Recording", bg='#37B7C3')
        self.unfreeze_gif()
        pause_duration = time.time() - self.pause_start_time
        self.start_time += pause_duration

    def update_timer(self):
        if self.is_recording:
            if not self.is_paused:
                self.elapsed_time = int(time.time() - self.start_time)
            self.timer_label.config(text=f"Timer: {self.elapsed_time} seconds")
            self.control_window.after(1000, self.update_timer)

    def record_audio(self):
        print("Recording...")
        while self.is_recording:
            if not self.is_paused:
                audio_chunk = sd.rec(int(self.fs), samplerate=self.fs, channels=2)
                sd.wait()
                self.audio_data.append(audio_chunk)
        print("Recording finished")

    def show_save_edit_window(self):
        self.save_edit_window = Toplevel(self.root)
        self.save_edit_window.title("Save or Edit Recording")
        self.save_edit_window.geometry("400x300")  # Increased window size
        self.save_edit_window.configure(bg='#050f28')

        filename_label = tk.Label(self.save_edit_window, text=f"File: {self.filename_base}{self.counter}.wav", bg='#050f28', fg='white', font=("Helvetica", 14))
        filename_label.pack(pady=20)

        save_button = tk.Button(self.save_edit_window, text="Save Recording", command=self.save_recording, bg='#8DECB4', font=("Helvetica", 14))
        save_button.pack(pady=20)

        edit_button = tk.Button(self.save_edit_window, text="Edit Recording", command=self.edit_recording, bg='orange', font=("Helvetica", 14))
        edit_button.pack(pady=20)

    def save_recording(self):
        if not os.path.exists("recordings"):
            os.makedirs("recordings")
        
        filename = os.path.join("recordings", f"{self.filename_base}{self.counter}.wav")
        self.save_audio(filename)
        messagebox.showinfo("Voice Recorder", f"Recording saved as {filename}")
        self.counter += 1
        self.save_edit_window.destroy()

    def edit_recording(self):
        self.edit_window = Toplevel(self.save_edit_window)
        self.edit_window.title("Edit Recording Name")
        self.edit_window.geometry("400x250")  # Increased window size
        self.edit_window.configure(bg='#050f28')

        name_label = tk.Label(self.edit_window, text="Enter new name:", bg='#050f28', fg='white', font=("Helvetica", 14))
        name_label.pack(pady=20)

        self.new_name_entry = Entry(self.edit_window, font=("Helvetica", 14))
        self.new_name_entry.insert(0, f"{self.filename_base}{self.counter}")
        self.new_name_entry.pack(pady=20)

        save_button = tk.Button(self.edit_window, text="Save", command=self.save_edited_name, bg='#8DECB4', font=("Helvetica", 14))
        save_button.pack(pady=20)

    def save_edited_name(self):
        new_name = self.new_name_entry.get()
        if new_name:
            if not os.path.exists("recordings"):
                os.makedirs("recordings")
            
            filename = os.path.join("recordings", f"{new_name}.wav")
            self.save_audio(filename)
            messagebox.showinfo("Voice Recorder", f"Recording saved as {filename}")
            self.counter += 1
            self.edit_window.destroy()
            self.save_edit_window.destroy()
        else:
            messagebox.showerror("Error", "Please enter a valid name.")

    def save_audio(self, filename):
        if self.audio_data:
            audio = np.concatenate(self.audio_data)
            wavio.write(filename, audio, self.fs, sampwidth=2)

    def show_recordings(self):
        self.recordings_window = Toplevel(self.root)
        self.recordings_window.title("Recordings")
        self.recordings_window.geometry("500x500")  # Increased window size
        self.recordings_window.configure(bg='#050f28')

        self.recordings_listbox = Listbox(self.recordings_window, bg='#e6e6e6', font=("Helvetica", 14), width=40, height=15)
        self.recordings_listbox.pack(pady=20)

        self.delete_button = tk.Button(self.recordings_window, text="Delete Recording", command=self.delete_recording, bg='orange', font=("Helvetica", 14))
        self.delete_button.pack(pady=20)

        self.load_recordings()

    def load_recordings(self):
        recordings = [f for f in os.listdir("recordings") if f.endswith('.wav')]
        for recording in recordings:
            self.recordings_listbox.insert(tk.END, recording)

    def delete_recording(self):
        selected_recording = self.recordings_listbox.curselection()
        if selected_recording:
            filename = self.recordings_listbox.get(selected_recording)
            full_path = os.path.join("recordings", filename)
            if os.path.exists(full_path):
                os.remove(full_path)
                self.recordings_listbox.delete(selected_recording)
                messagebox.showinfo("Voice Recorder", f"Recording {filename} deleted.")
            else:
                messagebox.showerror("Error", f"File {filename} not found.")
        else:
            messagebox.showerror("Error", "No recording selected.")

if __name__ == "__main__":
    root = tk.Tk()
    app = VoiceRecorderApp(root)
    root.mainloop()