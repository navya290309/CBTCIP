#this project has been maintained by Aryan Singh 
#under the guidance of CipherByte Technologies
#project name = MASTERMIND GAME
#Requires two player 



    def get_hint(secret, guess):
        hint = []
        for i in range(len(guess)):
            if i < len(secret) and guess[i] == secret[i]:
                hint.append(guess[i])
            else:
                hint.append('*')
        return ''.join(hint)

    def play_round(secret_setter, secret_guesser):
        secret_number = input(f"{secret_setter}, set a multi-digit number (make sure {secret_guesser} isn't looking): ")
        while not secret_number.isdigit() or len(secret_number) != 4:
            secret_number = input("Please enter a valid 4-digit number: ")
        attempts = 0
        life_left = 5
        guess_made = 0
    
        while life_left > 0:
            print("")
            guess = input(f"{secret_guesser}, guess the 4-digit number: ")
            attempts += 1
            guess_made += 1
        
            if guess == secret_number:
                print(f"Correct! {secret_guesser} guessed the number in {attempts} attempts.")
                break
            else:
                hint = get_hint(secret_number, guess)
            life_left -= 1
                print("")
                print(f"Nope that's Incorrect. Hint: {hint} was correct from given 4 digit. You have {life_left} life left.")
                print(f"Guesses made: {guess_made}")
    
        return attempts, guess_made

    def main():
        print("")
        print("")
        print("                                                  >----ॐ HAR HAR MAHADEV ॐ----<")
        print("                   >----Mastermind Game Built by Aryan Singh for project count in CipherByte Technologies----<")
        print("")
        print("")
        print("Welcome to the Mastermind game!")
        print("")
        p1 = input("Player 1, please enter your name: ")
        print("")
        p2 = input("Player 2, please enter your name: ")
        print("")
        print(f"{p1} and {p2} will take turns setting and guessing a 4-digit number.")
        print("")
    
        attempts_player2, guesses_made_player2 = play_round(p1, p2)
        attempts_player1, guesses_made_player1 = play_round(p2, p1)
    
        if attempts_player1 < attempts_player2:
            print(f"{p1} wins and is crowned Mastermind!")
        else:
            print(f"{p2} wins and is crowned Mastermind!")

    if __name__ == "__main__":
        main()
